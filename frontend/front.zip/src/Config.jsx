const apiURL = "https://fly-ai-backend-production.up.railway.app"

export default apiURL